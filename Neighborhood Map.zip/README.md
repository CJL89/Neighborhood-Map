NEIGHBORHOOD MAP

In order to use the map, just double click on the index.html and it will load the map automatically.
